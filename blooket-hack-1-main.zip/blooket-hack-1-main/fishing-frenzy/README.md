# Support discord server: https://discord.gg/TV8sYbe4RY

# fishing-frenzy

This cheat only works in fishing frenzy game mode!

# setWeight.js

### Get the script from the file [setWeight.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/fishing-frenzy/setWeight.js) or https://schoolcheats.net/blooket
