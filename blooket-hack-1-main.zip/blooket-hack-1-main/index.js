console.log('This cheat was made in javascript, and its obfuscated for very many purposes.')

//file made for indicator that its made in javascript.